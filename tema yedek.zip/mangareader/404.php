<?php 
defined("ABSPATH") || die("!");
get_header(); ?>

<div class="notf">
	<img src="<?php echo get_template_directory_uri(); ?>/assets/images/404.png" />
</div>
<?php get_footer(); ?>